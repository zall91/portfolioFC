import { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { Sun, Moon, Menu, X, LogOut } from 'lucide-react';
import CONFIG from '../config';

const NAV = [
  { path: '/',        num: '01', label: 'Bienvenue' },
  { path: '/cv',      num: '02', label: 'Parcours' },
  { path: '/projets', num: '03', label: 'Projets',   locked: true },
  { path: '/contact', num: '04', label: 'Contact' },
];

export default function Sidebar() {
  const { theme, toggleTheme } = useTheme();
  const { user, isAdmin, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const loc = useLocation();

  useEffect(() => { setMobileOpen(false); }, [loc.pathname]);

  return (
    <>
      <button
        className="menu-toggle"
        onClick={() => setMobileOpen(o => !o)}
        aria-label={mobileOpen ? 'Fermer' : 'Ouvrir le menu'}
      >
        {mobileOpen ? <X size={20} strokeWidth={1.5} /> : <Menu size={20} strokeWidth={1.5} />}
      </button>

      {mobileOpen && <div className="menu-backdrop" onClick={() => setMobileOpen(false)} />}

      <aside className={`rail ${mobileOpen ? 'rail--open' : ''}`}>
        {/* ── En-tête identitaire ─────────────────────────── */}
        <header className="rail__head">
          <div className="rail__mark">
            <span className="rail__mark-dot" />
            <span className="rail__mark-text">EN POSTE — 09 / 26</span>
          </div>
          <h1 className="rail__name">
            <span className="rail__first">{CONFIG.identity.firstName}</span>
            <span className="rail__last">{CONFIG.identity.lastName}</span>
          </h1>
          <p className="rail__discipline">
            Systèmes <span className="rail__amp">&amp;</span> réseaux,<br />
            <em>cybersécurité</em>
          </p>
        </header>

        {/* ── Navigation numérotée ────────────────────────── */}
        <nav className="rail__nav" aria-label="Sections">
          <div className="rail__nav-label">SOMMAIRE</div>
          <ul>
            {NAV.map(item => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `rail__link ${isActive ? 'rail__link--active' : ''}`
                  }
                >
                  <span className="rail__link-num">/{item.num}</span>
                  <span className="rail__link-label">{item.label}</span>
                  {item.locked && <span className="rail__link-lock" aria-label="Section protégée">⌬</span>}
                </NavLink>
              </li>
            ))}
            {!user && (
              <li>
                <NavLink to="/login" className={({ isActive }) =>
                  `rail__link rail__link--small ${isActive ? 'rail__link--active' : ''}`}>
                  <span className="rail__link-num">/05</span>
                  <span className="rail__link-label">Accès recruteur</span>
                </NavLink>
              </li>
            )}
            {isAdmin && (
              <li>
                <NavLink to="/admin" className={({ isActive }) =>
                  `rail__link rail__link--admin ${isActive ? 'rail__link--active' : ''}`}>
                  <span className="rail__link-num">/A</span>
                  <span className="rail__link-label">Régie</span>
                </NavLink>
              </li>
            )}
          </ul>
        </nav>

        {/* ── Pied : thème + déconnexion ──────────────────── */}
        <footer className="rail__foot">
          {user && (
            <button className="rail__action" onClick={logout}>
              <LogOut size={14} strokeWidth={1.5} />
              <span>Déconnexion <span className="rail__action-detail">({user.label || user.role})</span></span>
            </button>
          )}
          <button className="rail__action rail__theme" onClick={toggleTheme}
                  aria-label={`Passer en mode ${theme === 'dark' ? 'clair' : 'sombre'}`}>
            {theme === 'dark' ? <Sun size={14} strokeWidth={1.5} /> : <Moon size={14} strokeWidth={1.5} />}
            <span>{theme === 'dark' ? 'Mode clair' : 'Mode sombre'}</span>
          </button>
          <div className="rail__sig">
            <span className="rail__sig-line" />
            <span className="mono">v.2026 — Carantec, FR</span>
          </div>
        </footer>
      </aside>

      <style>{`
        .menu-toggle {
          display: none;
          position: fixed;
          top: 20px;
          left: 20px;
          z-index: 200;
          width: 40px;
          height: 40px;
          border: 1px solid var(--ink);
          background: var(--bg);
          color: var(--ink);
          cursor: pointer;
          align-items: center;
          justify-content: center;
          border-radius: 0;
        }
        .menu-backdrop {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(43, 24, 16, 0.4);
          z-index: 100;
          backdrop-filter: blur(2px);
        }
        .rail {
          position: sticky;
          top: 0;
          left: 0;
          height: 100vh;
          width: 240px;
          padding: 32px 24px;
          background: var(--bg);
          border-right: 1px solid var(--rule);
          display: flex;
          flex-direction: column;
          z-index: 150;
        }
        .rail__head {
          margin-bottom: 48px;
        }
        .rail__mark {
          display: flex;
          align-items: center;
          gap: 8px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.65rem;
          letter-spacing: 0.12em;
          color: var(--terracotta);
          margin-bottom: 32px;
        }
        .rail__mark-dot {
          width: 6px;
          height: 6px;
          background: var(--terracotta);
          border-radius: 50%;
          animation: pulse-soft 2.4s cubic-bezier(0.22, 1, 0.36, 1) infinite;
        }
        @keyframes pulse-soft {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(1.2); }
        }
        .rail__name {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: 1.95rem;
          line-height: 0.95;
          letter-spacing: -0.025em;
          margin-bottom: 12px;
          font-variation-settings: "opsz" 144, "SOFT" 80;
        }
        .rail__first {
          display: block;
          font-style: italic;
          font-weight: 300;
          color: var(--ink);
        }
        .rail__last {
          display: block;
          font-weight: 500;
          color: var(--ink);
          letter-spacing: -0.03em;
        }
        .rail__discipline {
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.85rem;
          line-height: 1.4;
          color: var(--ink-mute);
        }
        .rail__discipline em {
          font-family: 'Fraunces', serif;
          font-style: italic;
          font-weight: 400;
          color: var(--terracotta);
          font-size: 0.95rem;
        }
        .rail__amp {
          font-family: 'Fraunces', serif;
          font-style: italic;
          color: var(--terracotta);
          font-size: 1rem;
        }
        .rail__nav {
          flex: 1;
        }
        .rail__nav-label {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.65rem;
          letter-spacing: 0.16em;
          color: var(--ink-mute);
          margin-bottom: 16px;
        }
        .rail__nav ul {
          list-style: none;
        }
        .rail__link {
          display: flex;
          align-items: baseline;
          gap: 12px;
          padding: 8px 0;
          color: var(--ink-soft);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.95rem;
          font-weight: 400;
          text-decoration: none;
          transition: all 0.3s cubic-bezier(0.22, 1, 0.36, 1);
          position: relative;
        }
        .rail__link:hover {
          color: var(--terracotta);
          padding-left: 6px;
        }
        .rail__link--active {
          color: var(--ink);
          font-weight: 500;
        }
        .rail__link--active .rail__link-num {
          color: var(--terracotta);
        }
        .rail__link--active::before {
          content: '';
          position: absolute;
          left: -24px;
          top: 50%;
          transform: translateY(-50%);
          width: 16px;
          height: 1px;
          background: var(--terracotta);
        }
        .rail__link-num {
          font-family: 'JetBrains Mono', monospace;
          font-size: 0.7rem;
          letter-spacing: 0.06em;
          color: var(--ink-mute);
          flex-shrink: 0;
        }
        .rail__link-label {
          flex: 1;
        }
        .rail__link-lock {
          font-size: 0.7rem;
          color: var(--blush-deep);
        }
        .rail__link--admin {
          color: var(--warning);
          margin-top: 8px;
          padding-top: 12px;
          border-top: 1px dashed var(--rule);
        }
        .rail__link--admin .rail__link-num {
          color: var(--warning);
        }
        .rail__foot {
          padding-top: 24px;
          border-top: 1px solid var(--rule);
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .rail__action {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 6px 0;
          background: none;
          border: none;
          color: var(--ink-soft);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.85rem;
          cursor: pointer;
          transition: color 0.3s ease;
          text-align: left;
        }
        .rail__action:hover {
          color: var(--terracotta);
        }
        .rail__action-detail {
          color: var(--ink-mute);
          font-size: 0.75rem;
        }
        .rail__sig {
          margin-top: 16px;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .rail__sig-line {
          width: 24px;
          height: 1px;
          background: var(--terracotta);
        }
        .rail__sig .mono {
          font-size: 0.65rem;
          color: var(--ink-mute);
          letter-spacing: 0.05em;
        }
        @media (max-width: 900px) {
          .menu-toggle { display: flex; }
          .menu-backdrop { display: block; }
          .rail {
            position: fixed;
            transform: translateX(-100%);
            transition: transform 0.5s cubic-bezier(0.22, 1, 0.36, 1);
            box-shadow: var(--shadow-deep);
          }
          .rail--open { transform: translateX(0); }
        }
      `}</style>
    </>
  );
}
