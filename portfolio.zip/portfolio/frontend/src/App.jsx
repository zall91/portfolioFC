import { Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Home from './pages/Home';
import CV from './pages/CV';
import Projects from './pages/Projects';
import Contact from './pages/Contact';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';

// ── Tracking discret en arrière-plan ──────────────────────
function usePageTracking() {
  const location = useLocation();
  useEffect(() => {
    const sessionId = getSessionId();
    fetch('/api/tracking/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ page: location.pathname, sessionId })
    }).catch(() => {});
  }, [location.pathname]);
}

function getSessionId() {
  let sid = sessionStorage.getItem('portfolio-sid');
  if (!sid) {
    sid = 'sid_' + Math.random().toString(36).substring(2) + Date.now();
    sessionStorage.setItem('portfolio-sid', sid);
  }
  return sid;
}

export default function App() {
  usePageTracking();

  return (
    <div className="app-shell">
      <Sidebar />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cv" element={<CV />} />
          <Route path="/projets" element={<Projects />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<AdminDashboard />} />
        </Routes>
      </main>
    </div>
  );
}
