// ═══════════════════════════════════════════════════════════
// 📝 CONFIGURATION DU PORTFOLIO
// Modifie ce fichier pour personnaliser ton portfolio !
// ═══════════════════════════════════════════════════════════

const CONFIG = {

  // ── Informations personnelles ───────────────────────────
  identity: {
    firstName: "Prénom",
    lastName: "NOM",
    title: "Administrateur Systèmes & Réseaux",
    subtitle: "Spécialisé en Cybersécurité",
    tagline: "En recherche d'alternance",
    description: `Passionné par l'infrastructure IT et la cybersécurité, 
      je suis actuellement en formation BTS SIO SISR et à la recherche 
      d'une alternance pour mettre mes compétences au service de votre entreprise.`,
    avatar: null, // Chemin vers une photo (ex: "/avatar.jpg" dans le dossier public/)
  },

  // ── Coordonnées ─────────────────────────────────────────
  contact: {
    email: "ton.email@exemple.fr",
    phone: "+33 6 XX XX XX XX",
    linkedin: "https://linkedin.com/in/ton-profil",
    location: "Lorraine, France",
  },

  // ── Compétences techniques ──────────────────────────────
  skills: {
    "Systèmes": [
      { name: "Linux (Ubuntu/Debian)", level: 85 },
      { name: "Windows Server", level: 80 },
      { name: "VMware / Virtualisation", level: 85 },
      { name: "Docker & Portainer", level: 75 },
    ],
    "Réseaux": [
      { name: "TCP/IP, DNS, DHCP", level: 90 },
      { name: "VLANs & Routage", level: 80 },
      { name: "Pare-feu (pfSense)", level: 75 },
      { name: "VoIP / FreePBX", level: 70 },
    ],
    "Cybersécurité": [
      { name: "Analyse de vulnérabilités", level: 70 },
      { name: "Hardening système", level: 75 },
      { name: "Monitoring (Zabbix/Grafana)", level: 70 },
      { name: "Gestion des accès", level: 80 },
    ],
    "Outils & Scripting": [
      { name: "Bash / PowerShell", level: 80 },
      { name: "Git / GitHub", level: 75 },
      { name: "Ansible", level: 60 },
      { name: "FOG / Déploiement", level: 75 },
    ],
  },

  // ── Formations ──────────────────────────────────────────
  education: [
    {
      degree: "BTS SIO option SISR",
      school: "Ton Établissement",
      period: "2024 – 2026",
      description: "Solutions d'Infrastructure, Systèmes et Réseaux",
    },
    // Ajoute d'autres formations ici
  ],

  // ── Expériences ─────────────────────────────────────────
  experience: [
    {
      title: "Stagiaire Administrateur Systèmes",
      company: "Entreprise / Organisation",
      period: "2025",
      tasks: [
        "Administration de serveurs Linux et Windows",
        "Mise en place d'une infrastructure haute disponibilité",
        "Déploiement et configuration de services réseau",
      ],
    },
    // Ajoute d'autres expériences ici
  ],

  // ── Certifications ──────────────────────────────────────
  certifications: [
    // { name: "Cisco CCNA", year: "2025" },
    // { name: "CompTIA Security+", year: "2025" },
  ],

  // ── Projets (section protégée) ──────────────────────────
  projects: [
    {
      id: "ha-dolibarr",
      title: "Infrastructure Haute Disponibilité — Dolibarr",
      category: "Infrastructure",
      tags: ["MariaDB Galera", "Keepalived", "Apache", "Ubuntu"],
      summary: "Déploiement d'un ERP Dolibarr en haute disponibilité avec clustering de base de données et basculement automatique.",
      description: `Mise en place d'une architecture haute disponibilité complète pour l'ERP Dolibarr :
        - Cluster MariaDB Galera (3 nœuds) pour la réplication synchrone
        - Keepalived avec VIP pour le basculement automatique
        - Load balancing Apache avec répartition de charge
        - Monitoring et alerting de l'infrastructure`,
      technologies: ["MariaDB Galera", "Keepalived", "Apache2", "PHP", "VMware", "Ubuntu Server"],
      images: [], // Ajoute des chemins vers des screenshots
    },
    {
      id: "voip-freepbx",
      title: "Téléphonie VoIP — FreePBX",
      category: "Réseaux",
      tags: ["FreePBX", "Asterisk", "VoIP", "VLAN"],
      summary: "Implémentation d'une solution de téléphonie IP professionnelle avec FreePBX et segmentation réseau.",
      description: `Déploiement d'une infrastructure VoIP complète :
        - Installation et configuration de FreePBX / Asterisk
        - Segmentation réseau avec VLAN dédié (VLAN 31)
        - Configuration des postes SIP et des règles de routage d'appels
        - Documentation complète de l'architecture`,
      technologies: ["FreePBX", "Asterisk", "SIP", "VLAN", "VMware"],
      images: [],
    },
    {
      id: "docker-portainer",
      title: "Conteneurisation — Docker & Portainer",
      category: "DevOps",
      tags: ["Docker", "Portainer", "Monitoring"],
      summary: "Mise en place d'un environnement Docker avec interface de gestion Portainer et stack de monitoring.",
      description: `Environnement de conteneurisation complet :
        - Déploiement Docker avec Docker Compose
        - Interface de gestion via Portainer
        - Stack de monitoring (Grafana, Prometheus)
        - Documentation progressive (débutant à avancé)`,
      technologies: ["Docker", "Docker Compose", "Portainer", "Grafana", "Prometheus"],
      images: [],
    },
  ],
};

export default CONFIG;
