import { useState } from 'react';
import { Mail, Phone, Linkedin, MapPin, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import CONFIG from '../config';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [status, setStatus] = useState(null);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('sending');
    setError('');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setStatus('success');
      setForm({ name: '', email: '', subject: '', message: '' });
    } catch (err) {
      setStatus('error');
      setError(err.message || "Erreur lors de l'envoi");
    }
  }

  const channels = [
    { icon: Mail,     label: 'Email',     value: CONFIG.contact.email,    href: `mailto:${CONFIG.contact.email}` },
    { icon: Phone,    label: 'Téléphone', value: CONFIG.contact.phone,    href: `tel:${CONFIG.contact.phone}` },
    { icon: Linkedin, label: 'LinkedIn',  value: 'Profil LinkedIn',       href: CONFIG.contact.linkedin, external: true },
    { icon: MapPin,   label: 'Lieu',      value: CONFIG.contact.location, href: null },
  ];

  return (
    <article className="contact">

      <header className="contact__head rise-in rise-in--1">
        <span className="eyebrow">/04 — Contact</span>
        <h1 className="contact__title">
          <em>Discutons</em> d’une<br />
          <span className="scribble in-view">alternance.</span>
        </h1>
        <p className="contact__lede">
          Je réponds dans la journée du lundi au samedi.
          Pour les opportunités d’alternance qui démarrent en septembre 2026,
          n’hésitez pas même si l’offre n’est pas formellement publiée.
        </p>
      </header>

      <div className="contact__split">

        {/* ── Coordonnées éditoriales ───────────────────── */}
        <aside className="contact__channels rise-in rise-in--2">
          <span className="eyebrow contact__channels-label">CANAUX</span>
          <ul>
            {channels.map(c => (
              <li key={c.label} className="contact__channel">
                <div className="contact__channel-icon">
                  <c.icon size={16} strokeWidth={1.25} />
                </div>
                <div>
                  <div className="contact__channel-label mono">{c.label}</div>
                  {c.href ? (
                    <a href={c.href}
                       target={c.external ? '_blank' : undefined}
                       rel="noopener noreferrer"
                       className="contact__channel-value">
                      {c.value}
                      {c.external && <ArrowUpRight size={12} strokeWidth={1.5} style={{ marginLeft: 4 }} />}
                    </a>
                  ) : (
                    <span className="contact__channel-value">{c.value}</span>
                  )}
                </div>
              </li>
            ))}
          </ul>

          <div className="contact__avail">
            <span className="contact__avail-dot" />
            <div>
              <strong>Disponible pour la rentrée 2026.</strong>
              <p>Rythme privilégié : 1 semaine entreprise / 1 semaine école.</p>
            </div>
          </div>
        </aside>

        {/* ── Formulaire ─────────────────────────────────── */}
        <form className="contact__form rise-in rise-in--3" onSubmit={handleSubmit}>
          <span className="eyebrow contact__form-label">— OU ÉCRIVEZ-MOI ICI</span>

          {status === 'success' && (
            <div className="alert alert--success">
              <CheckCircle2 size={18} strokeWidth={1.5} />
              <span>Message reçu. Je vous réponds rapidement.</span>
            </div>
          )}
          {status === 'error' && (
            <div className="alert alert--error">{error}</div>
          )}

          <div className="field">
            <label className="field__label" htmlFor="ct-name">Nom complet *</label>
            <input id="ct-name" className="field__input" type="text" required
                   value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                   placeholder="Votre nom" />
          </div>

          <div className="field">
            <label className="field__label" htmlFor="ct-email">Email *</label>
            <input id="ct-email" className="field__input" type="email" required
                   value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                   placeholder="vous@entreprise.fr" />
          </div>

          <div className="field">
            <label className="field__label" htmlFor="ct-subject">Sujet</label>
            <input id="ct-subject" className="field__input" type="text"
                   value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })}
                   placeholder="Opportunité d'alternance, contact RH..." />
          </div>

          <div className="field">
            <label className="field__label" htmlFor="ct-msg">Message *</label>
            <textarea id="ct-msg" className="field__textarea" required rows={5}
                      value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
                      placeholder="Quelques lignes sur votre besoin..."/>
          </div>

          <button className="btn btn--primary" type="submit" disabled={status === 'sending'}>
            {status === 'sending' ? 'Envoi en cours…' : 'Envoyer le message'}
            <ArrowUpRight size={16} strokeWidth={1.5} />
          </button>
        </form>
      </div>

      <style>{`
        .contact {
          max-width: 1100px;
        }
        .contact__head {
          padding-bottom: 64px;
          margin-bottom: 64px;
          border-bottom: 1px solid var(--rule);
        }
        .contact__head .eyebrow { display: block; margin-bottom: 24px; }
        .contact__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2.5rem, 7vw, 5rem);
          line-height: 0.95;
          letter-spacing: -0.035em;
          font-variation-settings: "opsz" 144, "SOFT" 80;
          margin-bottom: 24px;
        }
        .contact__title em {
          font-style: italic;
          color: var(--terracotta);
        }
        .contact__lede {
          font-size: 1.1rem;
          color: var(--ink-soft);
          max-width: 560px;
          line-height: 1.65;
        }

        /* ── Split éditorial ──────────────────────────── */
        .contact__split {
          display: grid;
          grid-template-columns: 1fr 1.4fr;
          gap: 96px;
          align-items: start;
        }
        @media (max-width: 900px) {
          .contact__split { grid-template-columns: 1fr; gap: 48px; }
        }

        /* ── Channels ─────────────────────────────────── */
        .contact__channels-label { display: block; margin-bottom: 24px; }
        .contact__channels ul {
          list-style: none;
          display: flex;
          flex-direction: column;
        }
        .contact__channel {
          display: flex;
          gap: 16px;
          padding: 20px 0;
          border-bottom: 1px solid var(--rule);
          align-items: flex-start;
        }
        .contact__channel-icon {
          width: 36px;
          height: 36px;
          border: 1px solid var(--rule);
          color: var(--terracotta);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .contact__channel-label {
          font-size: 0.7rem;
          color: var(--ink-mute);
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 4px;
        }
        .contact__channel-value {
          font-family: 'Fraunces', serif;
          font-size: 1.1rem;
          color: var(--ink);
          font-style: italic;
          font-weight: 400;
          display: inline-flex;
          align-items: center;
        }
        a.contact__channel-value:hover { color: var(--terracotta); }

        .contact__avail {
          margin-top: 32px;
          padding: 24px;
          background: var(--bg-paper);
          border-left: 3px solid var(--terracotta);
          display: flex;
          gap: 16px;
          align-items: flex-start;
        }
        .contact__avail-dot {
          width: 8px;
          height: 8px;
          background: var(--terracotta);
          border-radius: 50%;
          margin-top: 8px;
          flex-shrink: 0;
          animation: pulse-soft 2.4s cubic-bezier(0.22, 1, 0.36, 1) infinite;
        }
        @keyframes pulse-soft {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(1.3); }
        }
        .contact__avail strong {
          display: block;
          font-family: 'Fraunces', serif;
          font-size: 1.05rem;
          font-weight: 500;
          color: var(--ink);
          margin-bottom: 4px;
        }
        .contact__avail p {
          font-size: 0.9rem;
          color: var(--ink-mute);
        }

        /* ── Form ─────────────────────────────────────── */
        .contact__form-label { display: block; margin-bottom: 32px; }
      `}</style>
    </article>
  );
}
