import { Link } from 'react-router-dom';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import CONFIG from '../config';

const PILLARS = [
  {
    num: '01',
    label: 'Infrastructure',
    teaser: 'Virtualisation, haute dispo, sauvegarde — tout ce qui ne doit pas tomber.',
    keywords: ['Proxmox', 'ZFS', 'VMware', 'Docker'],
  },
  {
    num: '02',
    label: 'Réseau',
    teaser: 'Du câble RJ45 au routage inter-VLAN, en passant par la VoIP.',
    keywords: ['Cisco', 'pfSense', 'VLAN', 'TCP/IP'],
  },
  {
    num: '03',
    label: 'Sécurité',
    teaser: 'Hardening, supervision, gestion des accès — le métier qui me passionne.',
    keywords: ['Hardening', 'Monitoring', 'IAM'],
  },
  {
    num: '04',
    label: 'Automatisation',
    teaser: 'Bash, PowerShell, Ansible — parce qu’une tâche faite trois fois mérite un script.',
    keywords: ['Bash', 'PowerShell', 'Ansible'],
  },
];

const NUMBERS = [
  { value: '03', label: 'années en formation\nBTS SIO SISR' },
  { value: '12+', label: 'projets infrastructure\nlivrés en stage' },
  { value: '24/7', label: 'disponibilité visée\nen production' },
];

export default function Home() {
  return (
    <article className="home">

      {/* ════════════ MASTHEAD ÉDITORIAL ════════════════════ */}
      <header className="home__masthead">
        <div className="home__meta rise-in rise-in--1">
          <span className="mono home__issue">N°01 — PORTFOLIO 2026</span>
          <span className="mono home__date">CARANTEC, BRETAGNE</span>
        </div>

        <h2 className="home__title rise-in rise-in--2">
          <span className="home__title-line home__title-line--1">
            Un alternant pour
          </span>
          <span className="home__title-line home__title-line--2">
            <em>tenir</em> votre
          </span>
          <span className="home__title-line home__title-line--3">
            <span className="scribble in-view">infrastructure</span>{' '}
            debout.
          </span>
        </h2>

        <div className="home__lede rise-in rise-in--3">
          <p>
            Bonjour. Je suis <strong>{CONFIG.identity.firstName} {CONFIG.identity.lastName}</strong>,
            étudiant en <span className="mono">BTS SIO SISR</span> à Carantec.
            Je cherche une entreprise pour mon alternance en
            <span className="scribble in-view"> Licence Pro ASUR</span>{' '}
            à partir de septembre&nbsp;2026 — administration systèmes &amp; réseaux,
            avec une spécialisation cybersécurité.
          </p>
        </div>

        <div className="home__cta rise-in rise-in--4">
          <Link to="/cv" className="btn btn--primary">
            Lire mon parcours
            <ArrowRight size={16} strokeWidth={1.5} />
          </Link>
          <Link to="/contact" className="btn btn--ghost">
            Me contacter
            <ArrowUpRight size={16} strokeWidth={1.5} />
          </Link>
        </div>
      </header>

      {/* ════════════ NUMÉROS CLÉS — bandeau éditorial ═════ */}
      <section className="home__numbers">
        {NUMBERS.map((n, i) => (
          <div key={i} className={`home__number rise-in rise-in--${i + 2}`}>
            <span className="home__number-value display">{n.value}</span>
            <span className="home__number-label mono">{n.label}</span>
          </div>
        ))}
      </section>

      {/* ════════════ BENTO DES 4 PILIERS ══════════════════ */}
      <section className="home__pillars">
        <div className="section-num">
          <span className="section-num__index">§ A</span>
          <h2 className="section-num__title">Quatre piliers,
            <em style={{ fontStyle: 'italic', color: 'var(--terracotta)' }}> un seul métier.</em>
          </h2>
        </div>

        <div className="bento">
          {PILLARS.map((p, i) => (
            <article key={p.num} className={`bento__cell bento__cell--${i + 1}`}>
              <div className="bento__head">
                <span className="bento__num mono">/{p.num}</span>
                <h3 className="bento__title">{p.label}</h3>
              </div>
              <p className="bento__teaser">{p.teaser}</p>
              <ul className="bento__kw">
                {p.keywords.map(k => (
                  <li key={k} className="mono">{k}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      {/* ════════════ PHRASE DE CLÔTURE ══════════════════════ */}
      <section className="home__quote">
        <p className="home__quote-text display">
          «&nbsp;Je veux que mes infrastructures<br />
          soient <span className="scribble scribble--bold in-view">invisibles</span> à l’usage<br />
          et <em>impeccables</em> à l’audit.&nbsp;»
        </p>
        <span className="home__quote-attr mono">
          — note de carnet, oct. 2025
        </span>
      </section>

      <style>{`
        .home {
          max-width: 1100px;
        }

        /* ── Masthead ───────────────────────────────────── */
        .home__masthead {
          padding: clamp(24px, 4vw, 48px) 0 64px;
          border-bottom: 1px solid var(--rule);
          margin-bottom: 64px;
          display: grid;
          grid-template-columns: 1fr;
          gap: 32px;
        }
        .home__meta {
          display: flex;
          justify-content: space-between;
          font-size: 0.7rem;
          letter-spacing: 0.12em;
          color: var(--ink-mute);
          padding-bottom: 16px;
          border-bottom: 1px solid var(--rule);
        }
        .home__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2.5rem, 8vw, 6rem);
          line-height: 0.92;
          letter-spacing: -0.035em;
          margin: 0;
          font-variation-settings: "opsz" 144, "SOFT" 80;
          color: var(--ink);
        }
        .home__title-line {
          display: block;
        }
        .home__title-line--2 {
          padding-left: clamp(20px, 6vw, 80px);
        }
        .home__title-line--2 em {
          font-style: italic;
          font-weight: 300;
          color: var(--terracotta);
        }
        .home__title-line--3 {
          padding-left: clamp(40px, 12vw, 160px);
        }
        .home__lede {
          max-width: 580px;
        }
        .home__lede p {
          font-family: 'Inter Tight', sans-serif;
          font-size: clamp(1rem, 1.5vw, 1.15rem);
          line-height: 1.65;
          color: var(--ink-soft);
        }
        .home__lede strong {
          color: var(--ink);
          font-weight: 600;
        }
        .home__cta {
          display: flex;
          gap: 16px;
          flex-wrap: wrap;
          margin-top: 8px;
        }

        /* ── Numéros clés ───────────────────────────────── */
        .home__numbers {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          padding: 48px 0;
          border-bottom: 1px solid var(--rule);
          margin-bottom: 64px;
        }
        .home__number {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .home__number-value {
          font-size: clamp(3rem, 8vw, 5.5rem);
          font-weight: 300;
          font-style: italic;
          color: var(--ink);
          line-height: 0.9;
          letter-spacing: -0.04em;
        }
        .home__number-label {
          font-size: 0.75rem;
          color: var(--ink-mute);
          letter-spacing: 0.08em;
          line-height: 1.5;
          white-space: pre-line;
        }
        @media (max-width: 700px) {
          .home__numbers { grid-template-columns: 1fr; gap: 32px; }
        }

        /* ── Bento piliers ──────────────────────────────── */
        .home__pillars {
          margin-bottom: 96px;
        }
        .bento {
          display: grid;
          grid-template-columns: repeat(12, 1fr);
          grid-auto-rows: minmax(220px, auto);
          gap: 16px;
        }
        .bento__cell {
          padding: 32px;
          background: var(--bg-paper);
          border: 1px solid var(--rule);
          display: flex;
          flex-direction: column;
          transition: all 0.5s cubic-bezier(0.22, 1, 0.36, 1);
          position: relative;
          overflow: hidden;
        }
        .bento__cell::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, transparent 0%, var(--blush) 200%);
          opacity: 0;
          transition: opacity 0.5s ease;
          pointer-events: none;
        }
        .bento__cell:hover {
          border-color: var(--terracotta);
          transform: translateY(-2px);
        }
        .bento__cell:hover::before {
          opacity: 0.15;
        }
        /* Asymétrie : grandes / petites cellules */
        .bento__cell--1 { grid-column: span 7; }
        .bento__cell--2 { grid-column: span 5; }
        .bento__cell--3 { grid-column: span 5; }
        .bento__cell--4 { grid-column: span 7; }
        @media (max-width: 800px) {
          .bento__cell { grid-column: span 12 !important; }
        }

        .bento__head {
          display: flex;
          align-items: baseline;
          gap: 16px;
          margin-bottom: 16px;
        }
        .bento__num {
          font-size: 0.85rem;
          color: var(--terracotta);
          letter-spacing: 0.08em;
        }
        .bento__title {
          font-family: 'Fraunces', serif;
          font-size: clamp(1.5rem, 3vw, 2rem);
          font-weight: 400;
          letter-spacing: -0.02em;
        }
        .bento__teaser {
          font-size: 0.95rem;
          color: var(--ink-soft);
          line-height: 1.65;
          flex: 1;
          margin-bottom: 24px;
        }
        .bento__kw {
          list-style: none;
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          padding-top: 16px;
          border-top: 1px solid var(--rule);
        }
        .bento__kw li {
          font-size: 0.7rem;
          color: var(--ink-mute);
          letter-spacing: 0.06em;
          padding: 4px 8px;
          background: var(--bg);
          border: 1px solid var(--rule);
        }

        /* ── Citation finale ─────────────────────────────── */
        .home__quote {
          padding: 64px 0;
          border-top: 1px solid var(--rule);
          margin-top: 32px;
          text-align: center;
        }
        .home__quote-text {
          font-size: clamp(1.6rem, 4vw, 2.8rem);
          line-height: 1.15;
          color: var(--ink);
          font-weight: 300;
          margin-bottom: 24px;
        }
        .home__quote-text em {
          font-style: italic;
          color: var(--terracotta);
        }
        .home__quote-attr {
          font-size: 0.75rem;
          color: var(--ink-mute);
          letter-spacing: 0.1em;
        }
      `}</style>
    </article>
  );
}
