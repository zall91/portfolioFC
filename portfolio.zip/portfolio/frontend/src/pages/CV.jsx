import CONFIG from '../config';

export default function CV() {
  const skillCategories = Object.entries(CONFIG.skills);

  return (
    <article className="cv">

      {/* ── Manchette ───────────────────────────────────── */}
      <header className="cv__head rise-in rise-in--1">
        <span className="eyebrow">/02 — Parcours</span>
        <h1 className="cv__title">
          Trois ans à <em>former</em><br />
          un <span className="scribble in-view">opérateur d’infra.</span>
        </h1>
        <p className="cv__intro">
          Compétences techniques, formations, expériences. Le détail
          du métier, pas la liste de mots-clés.
        </p>
      </header>

      {/* ── Compétences en bento ─────────────────────────── */}
      <section className="cv__section">
        <div className="section-num">
          <span className="section-num__index">§ A</span>
          <h2 className="section-num__title">Compétences techniques</h2>
        </div>

        <div className="cv__skills">
          {skillCategories.map(([category, skills], i) => (
            <div key={category} className={`cv__skill-cat rise-in rise-in--${(i % 4) + 1}`}>
              <h3 className="cv__skill-cat-title">{category}</h3>
              <ul className="cv__skill-list">
                {skills.map(skill => (
                  <li key={skill.name} className="cv__skill-row">
                    <span className="cv__skill-name">{skill.name}</span>
                    <span className="cv__skill-track">
                      <span className="cv__skill-fill" style={{ width: `${skill.level}%` }} />
                    </span>
                    <span className="cv__skill-num mono">{skill.level}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* ── Formations — colonne éditoriale ─────────────── */}
      <section className="cv__section">
        <div className="section-num">
          <span className="section-num__index">§ B</span>
          <h2 className="section-num__title">Formations</h2>
        </div>

        <div className="cv__timeline">
          {CONFIG.education.map((edu, i) => (
            <article key={i} className="cv__entry rise-in rise-in--2">
              <aside className="cv__entry-period mono">{edu.period}</aside>
              <div className="cv__entry-body">
                <h3 className="cv__entry-title">{edu.degree}</h3>
                <div className="cv__entry-place">{edu.school}</div>
                {edu.description && <p className="cv__entry-desc">{edu.description}</p>}
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ── Expériences ─────────────────────────────────── */}
      <section className="cv__section">
        <div className="section-num">
          <span className="section-num__index">§ C</span>
          <h2 className="section-num__title">Expériences</h2>
        </div>

        <div className="cv__timeline">
          {CONFIG.experience.map((exp, i) => (
            <article key={i} className="cv__entry rise-in rise-in--3">
              <aside className="cv__entry-period mono">{exp.period}</aside>
              <div className="cv__entry-body">
                <h3 className="cv__entry-title">{exp.title}</h3>
                <div className="cv__entry-place">{exp.company}</div>
                {exp.tasks && (
                  <ul className="cv__entry-tasks">
                    {exp.tasks.map((task, j) => (
                      <li key={j}>{task}</li>
                    ))}
                  </ul>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ── Certifications ──────────────────────────────── */}
      {CONFIG.certifications.length > 0 && (
        <section className="cv__section">
          <div className="section-num">
            <span className="section-num__index">§ D</span>
            <h2 className="section-num__title">Certifications</h2>
          </div>
          <div className="cv__certs">
            {CONFIG.certifications.map((c, i) => (
              <div key={i} className="cv__cert">
                <span className="display cv__cert-year">{c.year}</span>
                <span className="cv__cert-name">{c.name}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      <style>{`
        .cv {
          max-width: 1100px;
        }
        .cv__head {
          padding-bottom: 64px;
          margin-bottom: 64px;
          border-bottom: 1px solid var(--rule);
        }
        .cv__head .eyebrow {
          margin-bottom: 24px;
          display: block;
        }
        .cv__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2.5rem, 7vw, 5rem);
          line-height: 0.95;
          letter-spacing: -0.035em;
          font-variation-settings: "opsz" 144, "SOFT" 80;
          margin-bottom: 24px;
        }
        .cv__title em {
          font-style: italic;
          color: var(--terracotta);
        }
        .cv__intro {
          font-size: 1.1rem;
          color: var(--ink-soft);
          max-width: 580px;
          line-height: 1.65;
        }
        .cv__section {
          margin-bottom: 96px;
        }

        /* ── Skills ───────────────────────────────────── */
        .cv__skills {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 48px 64px;
        }
        @media (max-width: 800px) {
          .cv__skills { grid-template-columns: 1fr; gap: 48px; }
        }
        .cv__skill-cat-title {
          font-family: 'Fraunces', serif;
          font-size: 1.25rem;
          font-style: italic;
          font-weight: 400;
          color: var(--terracotta);
          margin-bottom: 16px;
          padding-bottom: 8px;
          border-bottom: 1px solid var(--rule);
        }
        .cv__skill-list {
          list-style: none;
        }
        .cv__skill-row {
          display: grid;
          grid-template-columns: 1fr 80px 32px;
          align-items: center;
          gap: 16px;
          padding: 10px 0;
          border-bottom: 1px solid var(--rule-soft);
        }
        .cv__skill-name {
          font-size: 0.95rem;
          color: var(--ink);
        }
        .cv__skill-track {
          height: 2px;
          background: var(--rule);
          position: relative;
        }
        .cv__skill-fill {
          position: absolute;
          inset: 0 auto 0 0;
          background: linear-gradient(90deg, var(--terracotta), var(--blush-deep));
          transition: width 1.5s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .cv__skill-num {
          font-size: 0.7rem;
          color: var(--ink-mute);
          text-align: right;
          letter-spacing: 0.05em;
        }

        /* ── Timeline ─────────────────────────────────── */
        .cv__timeline {
          display: flex;
          flex-direction: column;
          gap: 0;
        }
        .cv__entry {
          display: grid;
          grid-template-columns: 140px 1fr;
          gap: 48px;
          padding: 32px 0;
          border-top: 1px solid var(--rule);
          align-items: start;
        }
        .cv__entry:last-child {
          border-bottom: 1px solid var(--rule);
        }
        .cv__entry-period {
          font-size: 0.75rem;
          color: var(--terracotta);
          letter-spacing: 0.06em;
          padding-top: 4px;
        }
        .cv__entry-title {
          font-family: 'Fraunces', serif;
          font-size: 1.5rem;
          font-weight: 400;
          letter-spacing: -0.02em;
          margin-bottom: 4px;
        }
        .cv__entry-place {
          font-size: 0.9rem;
          color: var(--ink-mute);
          font-style: italic;
          font-family: 'Fraunces', serif;
          margin-bottom: 12px;
        }
        .cv__entry-desc {
          font-size: 0.95rem;
          color: var(--ink-soft);
          line-height: 1.65;
        }
        .cv__entry-tasks {
          list-style: none;
          margin-top: 12px;
        }
        .cv__entry-tasks li {
          font-size: 0.95rem;
          color: var(--ink-soft);
          padding: 6px 0;
          position: relative;
          padding-left: 20px;
          line-height: 1.5;
        }
        .cv__entry-tasks li::before {
          content: '—';
          position: absolute;
          left: 0;
          color: var(--terracotta);
        }
        @media (max-width: 700px) {
          .cv__entry { grid-template-columns: 1fr; gap: 12px; }
        }

        /* ── Certifs ──────────────────────────────────── */
        .cv__certs {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 24px;
        }
        .cv__cert {
          padding: 24px;
          border: 1px solid var(--rule);
          background: var(--bg-paper);
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .cv__cert-year {
          font-size: 2.5rem;
          color: var(--terracotta);
          font-style: italic;
          font-weight: 300;
          line-height: 1;
        }
        .cv__cert-name {
          font-size: 0.95rem;
          color: var(--ink);
        }
      `}</style>
    </article>
  );
}
