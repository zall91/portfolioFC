import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Key, KeyRound, ArrowUpRight, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [mode, setMode] = useState('password');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { loginWithPassword, loginWithCode, user } = useAuth();
  const navigate = useNavigate();

  if (user) {
    return (
      <article className="login login--connected">
        <div className="login__panel rise-in rise-in--1">
          <span className="eyebrow">/05 — Accès</span>
          <h1 className="login__title">Vous êtes <em>connecté</em>.</h1>
          <p className="login__lede">
            Identifié comme <strong>{user.label || user.role}</strong>
            {user.company && <> — {user.company}</>}.
          </p>
          <button className="btn btn--primary" onClick={() => navigate('/projets')}>
            Accéder aux projets
            <ArrowUpRight size={16} strokeWidth={1.5} />
          </button>
        </div>
        <style>{`
          .login--connected .login__panel {
            max-width: 580px;
            padding: 64px 0;
          }
          .login__title {
            font-family: 'Fraunces', serif;
            font-weight: 300;
            font-size: clamp(2.5rem, 6vw, 4rem);
            line-height: 0.95;
            letter-spacing: -0.035em;
            margin: 24px 0;
          }
          .login__title em { font-style: italic; color: var(--terracotta); }
          .login__lede {
            font-size: 1.1rem;
            color: var(--ink-soft);
            margin-bottom: 32px;
          }
        `}</style>
      </article>
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'password') await loginWithPassword(password);
      else await loginWithCode(code);
      navigate('/projets');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <article className="login">
      <div className="login__split">
        {/* ── Côté éditorial ──────────────────────────────── */}
        <div className="login__intro rise-in rise-in--1">
          <span className="eyebrow">/05 — Accès recruteur</span>
          <h1 className="login__title">
            Identifiez-vous,<br />
            je vous <span className="scribble in-view">ouvre la porte.</span>
          </h1>
          <p className="login__lede">
            Cette page est destinée aux personnes à qui j’ai communiqué
            un mot de passe ou un code d’accès personnel pour consulter
            mes projets en entreprise.
          </p>
          <div className="login__hint">
            <Lock size={14} strokeWidth={1.5} />
            <span>Pas reçu d’accès ? <a href="/contact">Contactez-moi.</a></span>
          </div>
        </div>

        {/* ── Formulaire ──────────────────────────────────── */}
        <div className="login__panel rise-in rise-in--2">
          <div className="login__tabs" role="tablist">
            <button role="tab"
                    className={`login__tab ${mode === 'password' ? 'login__tab--active' : ''}`}
                    onClick={() => { setMode('password'); setError(''); }}>
              <Key size={14} strokeWidth={1.5} /> Mot de passe
            </button>
            <button role="tab"
                    className={`login__tab ${mode === 'code' ? 'login__tab--active' : ''}`}
                    onClick={() => { setMode('code'); setError(''); }}>
              <KeyRound size={14} strokeWidth={1.5} /> Code d’accès
            </button>
          </div>

          {error && (
            <div className="alert alert--error">
              <AlertCircle size={18} strokeWidth={1.5} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {mode === 'password' ? (
              <div className="field">
                <label className="field__label" htmlFor="lg-pwd">Mot de passe partagé</label>
                <input id="lg-pwd" type="password" required autoFocus
                       className="field__input"
                       value={password}
                       onChange={e => setPassword(e.target.value)}
                       placeholder="Entrez le mot de passe" />
              </div>
            ) : (
              <div className="field">
                <label className="field__label" htmlFor="lg-code">Code d’accès personnel</label>
                <input id="lg-code" type="text" required autoFocus
                       className="field__input mono"
                       value={code}
                       onChange={e => setCode(e.target.value.toUpperCase())}
                       placeholder="XXXX-XXXX-XXXX-XXXX"
                       style={{ letterSpacing: '0.12em', fontSize: '1.1rem' }} />
                <p className="login__field-help">
                  Code de la forme <span className="mono">XXXX-XXXX-XXXX-XXXX</span> qui vous a été communiqué.
                </p>
              </div>
            )}

            <button type="submit" disabled={loading} className="btn btn--primary login__submit">
              {loading ? 'Vérification…' : 'Valider'}
              <ArrowUpRight size={16} strokeWidth={1.5} />
            </button>
          </form>
        </div>
      </div>

      <style>{`
        .login__split {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 96px;
          align-items: center;
          min-height: 70vh;
          padding: 48px 0;
        }
        @media (max-width: 900px) {
          .login__split { grid-template-columns: 1fr; gap: 48px; }
        }
        .login__intro .eyebrow { display: block; margin-bottom: 24px; }
        .login__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2rem, 5vw, 3.5rem);
          line-height: 0.95;
          letter-spacing: -0.03em;
          font-variation-settings: "opsz" 144, "SOFT" 80;
          margin-bottom: 24px;
        }
        .login__title em { font-style: italic; color: var(--terracotta); }
        .login__lede {
          font-size: 1.05rem;
          color: var(--ink-soft);
          line-height: 1.65;
          margin-bottom: 24px;
        }
        .login__hint {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 0.85rem;
          color: var(--ink-mute);
          padding: 8px 12px;
          border: 1px dashed var(--rule);
        }
        .login__hint a {
          color: var(--terracotta);
          text-decoration: underline;
          text-underline-offset: 3px;
        }
        .login__panel {
          padding: 40px;
          background: var(--bg-paper);
          border: 1px solid var(--rule);
        }
        .login__tabs {
          display: flex;
          gap: 0;
          margin-bottom: 32px;
          border-bottom: 1px solid var(--rule);
        }
        .login__tab {
          flex: 1;
          padding: 12px 16px;
          background: none;
          border: none;
          color: var(--ink-mute);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.9rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border-bottom: 2px solid transparent;
          margin-bottom: -1px;
          transition: all 0.3s ease;
        }
        .login__tab--active {
          color: var(--terracotta);
          border-bottom-color: var(--terracotta);
        }
        .login__field-help {
          font-size: 0.8rem;
          color: var(--ink-mute);
          margin-top: 8px;
        }
        .login__submit {
          width: 100%;
          justify-content: center;
        }
      `}</style>
    </article>
  );
}
