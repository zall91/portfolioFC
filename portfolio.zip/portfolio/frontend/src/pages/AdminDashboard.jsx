import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart3, Users, Eye, MessageSquare, Key,
  Plus, Trash2, ToggleLeft, ToggleRight, RefreshCw,
  Shield, Globe, FileText, AlertCircle, Mail
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AdminDashboard() {
  const { isAdmin, getAuthHeader } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('stats');
  const [stats, setStats] = useState(null);
  const [visitors, setVisitors] = useState([]);
  const [codes, setCodes] = useState([]);
  const [messages, setMessages] = useState([]);
  const [authLogs, setAuthLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newCode, setNewCode] = useState({ label: '', company: '', expiresIn: '30' });

  useEffect(() => { if (isAdmin) fetchAll(); }, [isAdmin]);

  if (!isAdmin) {
    return (
      <article className="admin admin--locked">
        <span className="eyebrow">/A — Régie</span>
        <h1 className="admin__title">Accès <em>refusé</em>.</h1>
        <p className="admin__lede">
          Cette section est réservée à l’administrateur.
        </p>
        <button className="btn btn--primary" onClick={() => navigate('/login')}>
          Se connecter
        </button>
        <style>{`
          .admin--locked { padding: 64px 0; }
          .admin--locked .eyebrow { display: block; margin-bottom: 24px; }
          .admin--locked .admin__title {
            font-family: 'Fraunces', serif; font-weight: 300;
            font-size: clamp(2.5rem, 6vw, 4rem); line-height: 0.95;
            margin-bottom: 24px;
          }
          .admin--locked .admin__title em { font-style: italic; color: var(--danger); }
          .admin--locked .admin__lede { color: var(--ink-soft); margin-bottom: 24px; }
        `}</style>
      </article>
    );
  }

  async function fetchAll() {
    setLoading(true);
    const headers = { ...getAuthHeader(), 'Content-Type': 'application/json' };
    try {
      const [s, v, c, m, l] = await Promise.all([
        fetch('/api/admin/stats',     { headers }).then(r => r.json()),
        fetch('/api/admin/visitors?limit=30', { headers }).then(r => r.json()),
        fetch('/api/admin/codes',     { headers }).then(r => r.json()),
        fetch('/api/admin/messages',  { headers }).then(r => r.json()),
        fetch('/api/admin/auth-logs', { headers }).then(r => r.json()),
      ]);
      setStats(s); setVisitors(v.visitors || []); setCodes(c); setMessages(m); setAuthLogs(l);
    } catch (err) { console.error(err); }
    setLoading(false);
  }

  async function createCode() {
    if (!newCode.label) return;
    const headers = { ...getAuthHeader(), 'Content-Type': 'application/json' };
    const res = await fetch('/api/admin/codes', { method: 'POST', headers, body: JSON.stringify(newCode) });
    const data = await res.json();
    setCodes([data, ...codes]);
    setNewCode({ label: '', company: '', expiresIn: '30' });
  }

  async function toggleCode(id) {
    const headers = getAuthHeader();
    await fetch(`/api/admin/codes/${id}/toggle`, { method: 'PATCH', headers });
    setCodes(codes.map(c => c.id === id ? { ...c, is_active: c.is_active ? 0 : 1 } : c));
  }

  async function deleteCode(id) {
    if (!confirm('Supprimer ce code ?')) return;
    await fetch(`/api/admin/codes/${id}`, { method: 'DELETE', headers: getAuthHeader() });
    setCodes(codes.filter(c => c.id !== id));
  }

  async function markRead(id) {
    await fetch(`/api/admin/messages/${id}/read`, { method: 'PATCH', headers: getAuthHeader() });
    setMessages(messages.map(m => m.id === id ? { ...m, is_read: 1 } : m));
  }

  const TABS = [
    { id: 'stats',    icon: BarChart3,     label: 'Vue d\'ensemble' },
    { id: 'visitors', icon: Users,         label: 'Visiteurs' },
    { id: 'codes',    icon: Key,           label: 'Codes' },
    { id: 'messages', icon: MessageSquare, label: 'Messages', badge: stats?.unreadMessages },
    { id: 'logs',     icon: Shield,        label: 'Auth.' },
  ];

  return (
    <article className="admin">

      <header className="admin__head rise-in rise-in--1">
        <span className="eyebrow">/A — Régie éditoriale</span>
        <h1 className="admin__title">
          Tableau de <em>bord</em>.
        </h1>
        <p className="admin__lede">
          Suivi des visiteurs, gestion des accès, messages reçus.
        </p>
      </header>

      {/* ── Tabs ──────────────────────────────────────────── */}
      <nav className="admin__tabs rise-in rise-in--2" aria-label="Sections">
        {TABS.map(t => (
          <button key={t.id}
                  className={`admin__tab ${tab === t.id ? 'admin__tab--active' : ''}`}
                  onClick={() => setTab(t.id)}>
            <t.icon size={14} strokeWidth={1.5} />
            <span>{t.label}</span>
            {t.badge ? <span className="admin__tab-badge mono">{t.badge}</span> : null}
          </button>
        ))}
        <button className="admin__refresh" onClick={fetchAll} aria-label="Rafraîchir">
          <RefreshCw size={14} strokeWidth={1.5} className={loading ? 'spinning' : ''} />
        </button>
      </nav>

      {loading && !stats ? (
        <div className="admin__loading mono">Chargement des données…</div>
      ) : (
        <div className="admin__panel rise-in rise-in--3">

          {/* ── STATS ───────────────────────────────────── */}
          {tab === 'stats' && stats && (
            <>
              <div className="admin__nums">
                <div className="admin__num">
                  <span className="display admin__num-val">{stats.totalVisitors}</span>
                  <span className="admin__num-lab mono">visiteurs au total</span>
                </div>
                <div className="admin__num">
                  <span className="display admin__num-val">{stats.todayVisitors}</span>
                  <span className="admin__num-lab mono">aujourd'hui</span>
                </div>
                <div className="admin__num">
                  <span className="display admin__num-val">{stats.totalPageViews}</span>
                  <span className="admin__num-lab mono">pages vues</span>
                </div>
                <div className="admin__num">
                  <span className="display admin__num-val" style={{ color: 'var(--terracotta)' }}>
                    {stats.totalMessages}
                  </span>
                  <span className="admin__num-lab mono">messages reçus</span>
                </div>
              </div>

              <div className="admin__split">
                <div className="bento-card">
                  <span className="bento-card__num">PAGES LES PLUS VUES</span>
                  {stats.topPages.length === 0 ? (
                    <p style={{ color: 'var(--ink-mute)' }}>Aucune donnée</p>
                  ) : stats.topPages.map(p => (
                    <div key={p.page} className="admin__row">
                      <span className="mono" style={{ fontSize: '0.85rem' }}>{p.page}</span>
                      <span className="display" style={{ color: 'var(--terracotta)', fontSize: '1.5rem' }}>
                        {p.views}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="bento-card">
                  <span className="bento-card__num">RÉPARTITION GÉOGRAPHIQUE</span>
                  {stats.countries.length === 0 ? (
                    <p style={{ color: 'var(--ink-mute)' }}>Aucune donnée</p>
                  ) : stats.countries.map(c => (
                    <div key={c.country} className="admin__row">
                      <span>{c.country || 'Inconnu'}</span>
                      <span className="display" style={{ color: 'var(--terracotta)', fontSize: '1.5rem' }}>
                        {c.count}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* ── VISITORS ────────────────────────────────── */}
          {tab === 'visitors' && (
            <div className="table-wrap">
              <table className="editorial-table">
                <thead>
                  <tr>
                    <th>IP</th><th>Lieu</th><th>Pages visitées</th>
                    <th>Visites</th><th>Première</th><th>Dernière</th>
                  </tr>
                </thead>
                <tbody>
                  {visitors.map(v => (
                    <tr key={v.id}>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>{v.ip}</td>
                      <td>{v.country || '—'}{v.city ? `, ${v.city}` : ''}</td>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>
                        {v.pages_visited?.split(',').slice(0, 3).join(' • ') || '—'}
                      </td>
                      <td><strong>{v.total_visits}</strong></td>
                      <td style={{ fontSize: '0.85rem' }}>{new Date(v.first_visit).toLocaleString('fr-FR')}</td>
                      <td style={{ fontSize: '0.85rem' }}>{new Date(v.last_visit).toLocaleString('fr-FR')}</td>
                    </tr>
                  ))}
                  {visitors.length === 0 && (
                    <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--ink-mute)' }}>Aucun visiteur enregistré</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* ── CODES ───────────────────────────────────── */}
          {tab === 'codes' && (
            <>
              <div className="admin__form">
                <h3 className="admin__form-title">Créer un nouveau code</h3>
                <div className="admin__form-grid">
                  <input className="field__input" placeholder="Nom du recruteur"
                         value={newCode.label} onChange={e => setNewCode({...newCode, label: e.target.value})} />
                  <input className="field__input" placeholder="Entreprise (optionnel)"
                         value={newCode.company} onChange={e => setNewCode({...newCode, company: e.target.value})} />
                  <select className="field__select" value={newCode.expiresIn}
                          onChange={e => setNewCode({...newCode, expiresIn: e.target.value})}>
                    <option value="7">Expire dans 7 jours</option>
                    <option value="14">14 jours</option>
                    <option value="30">30 jours</option>
                    <option value="90">90 jours</option>
                    <option value="">Pas d'expiration</option>
                  </select>
                  <button className="btn btn--primary" onClick={createCode}>
                    <Plus size={14} strokeWidth={1.5} /> Créer
                  </button>
                </div>
              </div>

              <div className="table-wrap">
                <table className="editorial-table">
                  <thead>
                    <tr>
                      <th>Code</th><th>Recruteur</th><th>Entreprise</th>
                      <th>Statut</th><th>Util.</th><th>Dernière</th><th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {codes.map(c => (
                      <tr key={c.id}>
                        <td className="mono" style={{ fontSize: '0.85rem', color: 'var(--terracotta)', fontWeight: 500 }}>
                          {c.code}
                        </td>
                        <td>{c.label}</td>
                        <td>{c.company || '—'}</td>
                        <td>
                          <span style={{ color: c.is_active ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
                            {c.is_active ? '● Actif' : '○ Inactif'}
                          </span>
                        </td>
                        <td>{c.use_count}</td>
                        <td style={{ fontSize: '0.8rem' }}>
                          {c.last_used_at ? new Date(c.last_used_at).toLocaleDateString('fr-FR') : '—'}
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="btn btn--sm" onClick={() => toggleCode(c.id)} title="Activer/désactiver">
                              {c.is_active ? <ToggleRight size={14} /> : <ToggleLeft size={14} />}
                            </button>
                            <button className="btn btn--sm btn--danger" onClick={() => deleteCode(c.id)} title="Supprimer">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {codes.length === 0 && (
                      <tr><td colSpan={7} style={{ textAlign: 'center', color: 'var(--ink-mute)' }}>Aucun code créé</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {/* ── MESSAGES ────────────────────────────────── */}
          {tab === 'messages' && (
            <>
              {messages.length === 0 ? (
                <div className="admin__empty">
                  <Mail size={32} strokeWidth={1.25} />
                  <p>Aucun message reçu pour le moment.</p>
                </div>
              ) : (
                <div className="admin__messages">
                  {messages.map(m => (
                    <article key={m.id} className={`admin__message ${m.is_read ? '' : 'admin__message--new'}`}>
                      <header className="admin__message-head">
                        <div>
                          <strong>{m.name}</strong>
                          <span className="mono admin__message-email"> · {m.email}</span>
                        </div>
                        <div className="admin__message-actions">
                          <span className="mono admin__message-date">
                            {new Date(m.created_at).toLocaleString('fr-FR')}
                          </span>
                          {!m.is_read && (
                            <button className="btn btn--sm btn--ghost" onClick={() => markRead(m.id)}>
                              Marquer lu
                            </button>
                          )}
                        </div>
                      </header>
                      {m.subject && (
                        <h4 className="admin__message-subject">{m.subject}</h4>
                      )}
                      <p className="admin__message-body">{m.message}</p>
                    </article>
                  ))}
                </div>
              )}
            </>
          )}

          {/* ── AUTH LOGS ───────────────────────────────── */}
          {tab === 'logs' && (
            <div className="table-wrap">
              <table className="editorial-table">
                <thead>
                  <tr><th>Date</th><th>IP</th><th>Méthode</th><th>Identifiant</th><th>Résultat</th></tr>
                </thead>
                <tbody>
                  {authLogs.map(log => (
                    <tr key={log.id}>
                      <td style={{ fontSize: '0.85rem' }}>{new Date(log.created_at).toLocaleString('fr-FR')}</td>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>{log.ip}</td>
                      <td>{log.method}</td>
                      <td>{log.identifier}</td>
                      <td>
                        <span style={{ color: log.success ? 'var(--success)' : 'var(--danger)', fontWeight: 500 }}>
                          {log.success ? '✓ Succès' : '✗ Échec'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {authLogs.length === 0 && (
                    <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--ink-mute)' }}>Aucune tentative enregistrée</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <style>{`
        .admin {
          max-width: 1200px;
        }
        .admin__head {
          padding-bottom: 48px;
          margin-bottom: 32px;
          border-bottom: 1px solid var(--rule);
        }
        .admin__head .eyebrow { display: block; margin-bottom: 16px; }
        .admin__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2rem, 5vw, 3.5rem);
          line-height: 0.95;
          letter-spacing: -0.03em;
          margin-bottom: 12px;
        }
        .admin__title em { font-style: italic; color: var(--terracotta); }
        .admin__lede { color: var(--ink-soft); }

        .admin__tabs {
          display: flex;
          gap: 4px;
          flex-wrap: wrap;
          margin-bottom: 32px;
          padding-bottom: 16px;
          border-bottom: 1px solid var(--rule);
        }
        .admin__tab {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          background: none;
          border: 1px solid transparent;
          color: var(--ink-mute);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.85rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .admin__tab:hover { color: var(--ink); }
        .admin__tab--active {
          color: var(--ink);
          background: var(--bg-paper);
          border-color: var(--rule);
        }
        .admin__tab-badge {
          font-size: 0.65rem;
          padding: 2px 6px;
          background: var(--terracotta);
          color: var(--bg);
        }
        .admin__refresh {
          margin-left: auto;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: none;
          border: 1px solid var(--rule);
          color: var(--ink-mute);
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .admin__refresh:hover { color: var(--terracotta); border-color: var(--terracotta); }
        @keyframes spin { to { transform: rotate(360deg); } }
        .spinning { animation: spin 1s linear infinite; }

        .admin__loading {
          padding: 64px 0;
          text-align: center;
          color: var(--ink-mute);
          font-size: 0.85rem;
          letter-spacing: 0.06em;
        }

        /* ── Numbers ──────────────────────────────────── */
        .admin__nums {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 24px;
          margin-bottom: 48px;
          padding-bottom: 48px;
          border-bottom: 1px solid var(--rule);
        }
        @media (max-width: 700px) {
          .admin__nums { grid-template-columns: repeat(2, 1fr); }
        }
        .admin__num {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .admin__num-val {
          font-size: clamp(2rem, 5vw, 3.5rem);
          font-style: italic;
          font-weight: 300;
          color: var(--ink);
          line-height: 0.9;
        }
        .admin__num-lab {
          font-size: 0.7rem;
          color: var(--ink-mute);
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }

        .admin__split {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
        }
        @media (max-width: 800px) {
          .admin__split { grid-template-columns: 1fr; }
        }
        .admin__row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 0;
          border-bottom: 1px solid var(--rule-soft);
        }
        .admin__row:last-child { border-bottom: none; }

        /* ── Form ─────────────────────────────────────── */
        .admin__form {
          padding: 24px;
          background: var(--bg-paper);
          border: 1px solid var(--rule);
          margin-bottom: 32px;
        }
        .admin__form-title {
          font-family: 'Fraunces', serif;
          font-style: italic;
          font-weight: 400;
          font-size: 1.1rem;
          color: var(--terracotta);
          margin-bottom: 16px;
        }
        .admin__form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr 180px auto;
          gap: 16px;
          align-items: end;
        }
        @media (max-width: 800px) {
          .admin__form-grid { grid-template-columns: 1fr; }
        }

        .table-wrap {
          overflow-x: auto;
          border: 1px solid var(--rule);
          background: var(--bg-paper);
        }

        /* ── Messages ─────────────────────────────────── */
        .admin__empty {
          padding: 64px;
          text-align: center;
          color: var(--ink-mute);
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
          border: 1px dashed var(--rule);
        }
        .admin__messages {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .admin__message {
          padding: 24px;
          background: var(--bg-paper);
          border: 1px solid var(--rule);
          position: relative;
        }
        .admin__message--new {
          border-left: 3px solid var(--terracotta);
        }
        .admin__message-head {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          flex-wrap: wrap;
          gap: 12px;
          margin-bottom: 12px;
        }
        .admin__message-email {
          font-size: 0.85rem;
          color: var(--ink-mute);
        }
        .admin__message-actions {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        .admin__message-date {
          font-size: 0.75rem;
          color: var(--ink-mute);
        }
        .admin__message-subject {
          font-family: 'Fraunces', serif;
          font-style: italic;
          font-weight: 400;
          font-size: 1.05rem;
          color: var(--terracotta);
          margin-bottom: 8px;
        }
        .admin__message-body {
          color: var(--ink-soft);
          line-height: 1.65;
          white-space: pre-wrap;
        }
      `}</style>
    </article>
  );
}
