import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, ArrowUpRight, Plus, Minus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import CONFIG from '../config';

export default function Projects() {
  const { isRecruiter, user } = useAuth();
  const navigate = useNavigate();
  const [openId, setOpenId] = useState(null);
  const [filter, setFilter] = useState('all');

  // ── Section verrouillée ─────────────────────────────
  if (!isRecruiter) {
    return (
      <article className="proj-locked">
        <header className="proj-locked__head rise-in rise-in--1">
          <span className="eyebrow">/03 — Projets</span>
          <h1 className="proj-locked__title">
            Cette section est<br />
            <span className="scribble in-view">réservée</span> aux recruteurs.
          </h1>
        </header>

        <div className="proj-locked__body rise-in rise-in--2">
          <div className="proj-locked__icon">
            <Lock size={28} strokeWidth={1.25} />
          </div>
          <p className="proj-locked__text">
            Les détails de mes projets en entreprise contiennent des
            informations sur des infrastructures clientes. Je préfère
            les partager <em>uniquement</em> avec les personnes qui m’ont
            contactée pour une opportunité d’alternance.
          </p>
          <p className="proj-locked__text proj-locked__text--mute">
            Si vous m’avez communiqué un mot de passe ou un code d’accès
            personnel, utilisez-le ci-dessous.
          </p>

          <button className="btn btn--primary" onClick={() => navigate('/login')}>
            Saisir un accès
            <ArrowUpRight size={16} strokeWidth={1.5} />
          </button>
        </div>

        <style>{`
          .proj-locked {
            max-width: 800px;
            padding: 32px 0;
          }
          .proj-locked__head {
            padding-bottom: 64px;
            margin-bottom: 64px;
            border-bottom: 1px solid var(--rule);
          }
          .proj-locked__head .eyebrow {
            display: block;
            margin-bottom: 24px;
          }
          .proj-locked__title {
            font-family: 'Fraunces', serif;
            font-weight: 300;
            font-size: clamp(2.5rem, 7vw, 5rem);
            line-height: 0.95;
            letter-spacing: -0.035em;
            font-variation-settings: "opsz" 144, "SOFT" 80;
          }
          .proj-locked__body {
            display: flex;
            flex-direction: column;
            gap: 24px;
            align-items: flex-start;
            max-width: 580px;
          }
          .proj-locked__icon {
            width: 56px;
            height: 56px;
            border: 1px solid var(--terracotta);
            color: var(--terracotta);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
          }
          .proj-locked__text {
            font-size: 1.05rem;
            color: var(--ink-soft);
            line-height: 1.7;
          }
          .proj-locked__text em {
            font-style: italic;
            font-family: 'Fraunces', serif;
            color: var(--terracotta);
          }
          .proj-locked__text--mute {
            font-size: 0.9rem;
            color: var(--ink-mute);
          }
        `}</style>
      </article>
    );
  }

  // ── Section déverrouillée ───────────────────────────
  const categories = ['all', ...new Set(CONFIG.projects.map(p => p.category))];
  const filtered = filter === 'all' ? CONFIG.projects : CONFIG.projects.filter(p => p.category === filter);

  return (
    <article className="proj">
      <header className="proj__head rise-in rise-in--1">
        <span className="eyebrow">/03 — Projets</span>
        <h1 className="proj__title">
          Bonjour <em>{user?.label || 'recruteur'}</em>{user?.company && <>, <span className="scribble in-view">{user.company}</span></>}.
        </h1>
        <p className="proj__lede">
          Voici une sélection de mes réalisations en infrastructure.
          Cliquez sur un projet pour voir le détail technique.
        </p>
      </header>

      {/* ── Filtres ──────────────────────────────────── */}
      <nav className="proj__filters rise-in rise-in--2" aria-label="Filtrer par catégorie">
        {categories.map(cat => (
          <button
            key={cat}
            className={`proj__filter ${filter === cat ? 'proj__filter--active' : ''}`}
            onClick={() => setFilter(cat)}
          >
            {cat === 'all' ? 'Tous' : cat}
            <span className="proj__filter-count mono">
              {cat === 'all' ? CONFIG.projects.length : CONFIG.projects.filter(p => p.category === cat).length}
            </span>
          </button>
        ))}
      </nav>

      {/* ── Grille éditoriale (alternance) ─────────────── */}
      <div className="proj__grid">
        {filtered.map((project, i) => {
          const isOpen = openId === project.id;
          return (
            <article
              key={project.id}
              className={`proj-card ${isOpen ? 'proj-card--open' : ''} rise-in rise-in--${(i % 4) + 1}`}
            >
              <div className="proj-card__num mono">/{String(i + 1).padStart(2, '0')}</div>

              <div className="proj-card__head">
                <span className="tag tag--accent">{project.category}</span>
                <h3 className="proj-card__title">{project.title}</h3>
                <p className="proj-card__summary">{project.summary}</p>
              </div>

              <div className="proj-card__tags">
                {project.tags.map(t => (
                  <span key={t} className="mono proj-card__tag">{t}</span>
                ))}
              </div>

              <button
                className="proj-card__expand"
                onClick={() => setOpenId(isOpen ? null : project.id)}
              >
                {isOpen ? (
                  <><Minus size={14} strokeWidth={1.5} /> Réduire</>
                ) : (
                  <><Plus size={14} strokeWidth={1.5} /> Détails techniques</>
                )}
              </button>

              {isOpen && (
                <div className="proj-card__body">
                  <p className="proj-card__desc">{project.description}</p>
                  <div className="proj-card__tech">
                    <span className="eyebrow">Stack technique</span>
                    <div className="proj-card__tech-list">
                      {project.technologies.map(t => (
                        <span key={t} className="tag">{t}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Ping trace au hover — détail métier */}
              <div className="proj-card__trace mono">
                <span className="proj-card__trace-arrow">▸</span> trace {project.id}.francois.local
              </div>
            </article>
          );
        })}
      </div>

      <style>{`
        .proj {
          max-width: 1100px;
        }
        .proj__head {
          padding-bottom: 48px;
          margin-bottom: 48px;
          border-bottom: 1px solid var(--rule);
        }
        .proj__head .eyebrow { display: block; margin-bottom: 24px; }
        .proj__title {
          font-family: 'Fraunces', serif;
          font-weight: 300;
          font-size: clamp(2.5rem, 7vw, 5rem);
          line-height: 0.95;
          letter-spacing: -0.035em;
          font-variation-settings: "opsz" 144, "SOFT" 80;
          margin-bottom: 24px;
        }
        .proj__title em {
          font-style: italic;
          color: var(--terracotta);
        }
        .proj__lede {
          font-size: 1.1rem;
          color: var(--ink-soft);
          max-width: 580px;
          line-height: 1.65;
        }

        /* ── Filtres ──────────────────────────────────── */
        .proj__filters {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 48px;
        }
        .proj__filter {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          border: 1px solid var(--rule);
          background: transparent;
          color: var(--ink-soft);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.85rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .proj__filter:hover { border-color: var(--terracotta); color: var(--terracotta); }
        .proj__filter--active {
          background: var(--ink);
          color: var(--bg);
          border-color: var(--ink);
        }
        .proj__filter-count {
          font-size: 0.7rem;
          opacity: 0.6;
        }

        /* ── Cards ────────────────────────────────────── */
        .proj__grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 24px;
        }
        @media (max-width: 800px) {
          .proj__grid { grid-template-columns: 1fr; }
        }
        .proj-card {
          padding: 32px;
          background: var(--bg-paper);
          border: 1px solid var(--rule);
          display: flex;
          flex-direction: column;
          position: relative;
          transition: all 0.4s cubic-bezier(0.22, 1, 0.36, 1);
          overflow: hidden;
        }
        .proj-card:hover {
          border-color: var(--terracotta);
          background: var(--bg-soft);
        }
        .proj-card--open {
          grid-column: 1 / -1;
        }
        .proj-card__num {
          position: absolute;
          top: 16px;
          right: 20px;
          font-size: 0.7rem;
          color: var(--ink-mute);
          letter-spacing: 0.08em;
        }
        .proj-card__head .tag {
          margin-bottom: 16px;
        }
        .proj-card__title {
          font-family: 'Fraunces', serif;
          font-size: 1.5rem;
          font-weight: 400;
          letter-spacing: -0.02em;
          line-height: 1.2;
          margin-bottom: 12px;
        }
        .proj-card__summary {
          font-size: 0.95rem;
          color: var(--ink-soft);
          line-height: 1.65;
          margin-bottom: 20px;
          flex: 1;
        }
        .proj-card__tags {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
          margin-bottom: 20px;
          padding-top: 16px;
          border-top: 1px solid var(--rule);
        }
        .proj-card__tag {
          font-size: 0.7rem;
          color: var(--ink-mute);
          padding: 3px 7px;
          border: 1px solid var(--rule);
          background: var(--bg);
        }
        .proj-card__expand {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: transparent;
          border: none;
          color: var(--terracotta);
          font-family: 'Inter Tight', sans-serif;
          font-size: 0.9rem;
          cursor: pointer;
          align-self: flex-start;
          padding: 0;
          transition: gap 0.3s ease;
        }
        .proj-card__expand:hover { gap: 12px; }

        .proj-card__body {
          margin-top: 24px;
          padding-top: 24px;
          border-top: 1px solid var(--rule);
          animation: rise-in 0.5s ease both;
        }
        .proj-card__desc {
          font-size: 0.95rem;
          color: var(--ink-soft);
          line-height: 1.7;
          white-space: pre-line;
          margin-bottom: 24px;
        }
        .proj-card__tech .eyebrow { display: block; margin-bottom: 12px; }
        .proj-card__tech-list {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        /* ── Ping trace (détail "waouh") ──────────────── */
        .proj-card__trace {
          position: absolute;
          bottom: 12px;
          left: 32px;
          right: 32px;
          font-size: 0.65rem;
          color: var(--terracotta);
          opacity: 0;
          transform: translateY(8px);
          transition: opacity 0.3s ease, transform 0.4s cubic-bezier(0.22, 1, 0.36, 1);
          pointer-events: none;
          letter-spacing: 0.04em;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .proj-card:hover .proj-card__trace {
          opacity: 0.8;
          transform: translateY(0);
        }
        .proj-card__trace-arrow {
          color: var(--blush-deep);
          margin-right: 4px;
        }
      `}</style>
    </article>
  );
}
