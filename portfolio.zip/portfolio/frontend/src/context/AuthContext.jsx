import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('portfolio-token');
    if (token) {
      verifyToken(token);
    } else {
      setLoading(false);
    }
  }, []);

  async function verifyToken(token) {
    try {
      const res = await fetch('/api/auth/verify', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser({ ...data.user, token });
      } else {
        localStorage.removeItem('portfolio-token');
      }
    } catch {
      localStorage.removeItem('portfolio-token');
    }
    setLoading(false);
  }

  async function loginWithPassword(password) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('portfolio-token', data.token);
    setUser({ ...data, token: data.token });
    return data;
  }

  async function loginWithCode(code) {
    const res = await fetch('/api/auth/code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('portfolio-token', data.token);
    setUser({ ...data, token: data.token });
    return data;
  }

  function logout() {
    localStorage.removeItem('portfolio-token');
    setUser(null);
  }

  function getAuthHeader() {
    const token = localStorage.getItem('portfolio-token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  return (
    <AuthContext.Provider value={{
      user, loading, loginWithPassword, loginWithCode, logout, getAuthHeader,
      isAdmin: user?.role === 'admin',
      isRecruiter: user?.role === 'recruiter' || user?.role === 'admin',
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
