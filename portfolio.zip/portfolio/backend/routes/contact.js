const express = require('express');
const router = express.Router();
const { getDB } = require('../db/init');

// ── Envoyer un message de contact ───────────────────────
router.post('/', (req, res) => {
  try {
    const db = getDB();
    const { name, email, subject, message } = req.body;
    const ip = req.headers['x-real-ip'] || req.ip;

    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Nom, email et message requis' });
    }

    // Rate limiting simple : max 5 messages par IP par heure
    const recentCount = db.prepare(`
      SELECT COUNT(*) as count FROM contact_messages 
      WHERE ip = ? AND created_at >= datetime('now', '-1 hour')
    `).get(ip).count;

    if (recentCount >= 5) {
      return res.status(429).json({ error: 'Trop de messages envoyés. Réessayez plus tard.' });
    }

    db.prepare(`
      INSERT INTO contact_messages (name, email, subject, message, ip)
      VALUES (?, ?, ?, ?, ?)
    `).run(name, email, subject || '', message, ip);

    res.json({ success: true, message: 'Message envoyé avec succès' });
  } catch (err) {
    console.error('[Contact] Erreur:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
