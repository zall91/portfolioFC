const express = require('express');
const router = express.Router();
const { getDB } = require('../db/init');
const { v4: uuidv4 } = require('uuid');

function getGeoInfo(ip) {
  try {
    const geoip = require('geoip-lite');
    const cleanIP = ip.replace(/^::ffff:/, '');
    const geo = geoip.lookup(cleanIP);
    if (geo) return { country: geo.country, city: geo.city, region: geo.region };
  } catch (e) { /* ignore */ }
  return { country: null, city: null, region: null };
}

// ── Enregistrer une visite / page vue ───────────────────
router.post('/track', (req, res) => {
  try {
    const db = getDB();
    const { page, sessionId } = req.body;
    const ip = req.headers['x-real-ip'] || req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip;
    const userAgent = req.headers['user-agent'] || 'unknown';
    const referer = req.headers['referer'] || null;
    const geo = getGeoInfo(ip);

    const sessionKey = sessionId || `${ip}_${Buffer.from(userAgent).toString('base64').substring(0, 50)}`;

    let visitor = db.prepare('SELECT * FROM visitors WHERE session_id = ?').get(sessionKey);

    if (!visitor) {
      const id = uuidv4();
      db.prepare(`
        INSERT INTO visitors (id, session_id, ip, user_agent, country, city, region, referer)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, sessionKey, ip, userAgent, geo.country, geo.city, geo.region, referer);
      visitor = { id };
    } else {
      db.prepare(`
        UPDATE visitors SET last_visit = CURRENT_TIMESTAMP, total_visits = total_visits + 1 WHERE id = ?
      `).run(visitor.id);
    }

    if (page) {
      db.prepare('INSERT INTO page_views (visitor_id, page) VALUES (?, ?)').run(visitor.id, page);
    }

    res.json({ ok: true, visitorId: visitor.id });
  } catch (err) {
    console.error('[Track] Erreur:', err.message);
    res.status(500).json({ error: 'Erreur tracking' });
  }
});

// ── Mettre à jour le temps passé sur une page ───────────
router.post('/time', (req, res) => {
  try {
    const db = getDB();
    const { pageViewId, seconds } = req.body;
    if (pageViewId && seconds) {
      db.prepare('UPDATE page_views SET time_spent_seconds = ? WHERE id = ?').run(seconds, pageViewId);
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Erreur' });
  }
});

module.exports = router;
