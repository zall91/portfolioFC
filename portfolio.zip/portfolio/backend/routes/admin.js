const express = require('express');
const router = express.Router();
const { getDB } = require('../db/init');
const { verifyToken, requireAdmin } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// Toutes les routes admin nécessitent auth admin
router.use(verifyToken, requireAdmin);

// ── Dashboard Analytics ─────────────────────────────────
router.get('/stats', (req, res) => {
  const db = getDB();

  const totalVisitors = db.prepare('SELECT COUNT(*) as count FROM visitors').get().count;
  const todayVisitors = db.prepare(`
    SELECT COUNT(*) as count FROM visitors 
    WHERE date(first_visit) = date('now')
  `).get().count;
  const totalPageViews = db.prepare('SELECT COUNT(*) as count FROM page_views').get().count;
  const totalMessages = db.prepare('SELECT COUNT(*) as count FROM contact_messages').get().count;
  const unreadMessages = db.prepare('SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0').get().count;

  // Visiteurs par jour (30 derniers jours)
  const dailyVisitors = db.prepare(`
    SELECT date(first_visit) as day, COUNT(*) as count 
    FROM visitors 
    WHERE first_visit >= datetime('now', '-30 days')
    GROUP BY date(first_visit) ORDER BY day
  `).all();

  // Pages les plus vues
  const topPages = db.prepare(`
    SELECT page, COUNT(*) as views 
    FROM page_views 
    GROUP BY page ORDER BY views DESC LIMIT 10
  `).all();

  // Pays des visiteurs
  const countries = db.prepare(`
    SELECT country, COUNT(*) as count 
    FROM visitors WHERE country IS NOT NULL
    GROUP BY country ORDER BY count DESC LIMIT 10
  `).all();

  res.json({
    totalVisitors,
    todayVisitors,
    totalPageViews,
    totalMessages,
    unreadMessages,
    dailyVisitors,
    topPages,
    countries
  });
});

// ── Liste des visiteurs ─────────────────────────────────
router.get('/visitors', (req, res) => {
  const db = getDB();
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 50;
  const offset = (page - 1) * limit;

  const visitors = db.prepare(`
    SELECT v.*, 
      (SELECT COUNT(*) FROM page_views WHERE visitor_id = v.id) as page_count,
      (SELECT GROUP_CONCAT(DISTINCT page) FROM page_views WHERE visitor_id = v.id) as pages_visited
    FROM visitors v
    ORDER BY v.last_visit DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset);

  const total = db.prepare('SELECT COUNT(*) as count FROM visitors').get().count;

  res.json({ visitors, total, page, limit });
});

// ── Gestion des codes d'accès ───────────────────────────
router.get('/codes', (req, res) => {
  const db = getDB();
  const codes = db.prepare('SELECT * FROM access_codes ORDER BY created_at DESC').all();
  res.json(codes);
});

router.post('/codes', (req, res) => {
  const db = getDB();
  const { label, company, expiresIn } = req.body;

  if (!label) return res.status(400).json({ error: 'Label requis' });

  const id = uuidv4();
  // Générer un code lisible : 4 groupes de 4 caractères
  const code = Array.from({ length: 4 }, () =>
    Math.random().toString(36).substring(2, 6).toUpperCase()
  ).join('-');

  let expiresAt = null;
  if (expiresIn) {
    const date = new Date();
    date.setDate(date.getDate() + parseInt(expiresIn));
    expiresAt = date.toISOString();
  }

  db.prepare(`
    INSERT INTO access_codes (id, code, label, company, expires_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(id, code, label, company || '', expiresAt);

  const newCode = db.prepare('SELECT * FROM access_codes WHERE id = ?').get(id);
  res.json(newCode);
});

router.delete('/codes/:id', (req, res) => {
  const db = getDB();
  db.prepare('DELETE FROM access_codes WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

router.patch('/codes/:id/toggle', (req, res) => {
  const db = getDB();
  db.prepare('UPDATE access_codes SET is_active = NOT is_active WHERE id = ?').run(req.params.id);
  const code = db.prepare('SELECT * FROM access_codes WHERE id = ?').get(req.params.id);
  res.json(code);
});

// ── Logs de connexion ───────────────────────────────────
router.get('/auth-logs', (req, res) => {
  const db = getDB();
  const logs = db.prepare(`
    SELECT * FROM auth_logs ORDER BY created_at DESC LIMIT 100
  `).all();
  res.json(logs);
});

// ── Messages de contact ─────────────────────────────────
router.get('/messages', (req, res) => {
  const db = getDB();
  const messages = db.prepare('SELECT * FROM contact_messages ORDER BY created_at DESC').all();
  res.json(messages);
});

router.patch('/messages/:id/read', (req, res) => {
  const db = getDB();
  db.prepare('UPDATE contact_messages SET is_read = 1 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

router.delete('/messages/:id', (req, res) => {
  const db = getDB();
  db.prepare('DELETE FROM contact_messages WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
