const express = require('express');
const router = express.Router();
const { getDB } = require('../db/init');
const { generateToken } = require('../middleware/auth');

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin';
const RECRUITER_PASSWORD = process.env.RECRUITER_PASSWORD || 'recruteur2025';

// ── Login avec mot de passe (admin ou recruteur) ────────
router.post('/login', (req, res) => {
  const { password } = req.body;
  const ip = req.headers['x-real-ip'] || req.ip;
  const db = getDB();

  if (!password) {
    return res.status(400).json({ error: 'Mot de passe requis' });
  }

  // Vérifier admin
  if (password === ADMIN_PASSWORD) {
    db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
      .run(ip, 'password', 'admin', 1);
    
    const token = generateToken({ role: 'admin', label: 'Administrateur' });
    return res.json({ token, role: 'admin', label: 'Administrateur' });
  }

  // Vérifier recruteur
  if (password === RECRUITER_PASSWORD) {
    db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
      .run(ip, 'password', 'recruiter', 1);

    const token = generateToken({ role: 'recruiter', label: 'Recruteur' });
    return res.json({ token, role: 'recruiter', label: 'Recruteur' });
  }

  // Échec
  db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
    .run(ip, 'password', 'failed', 0);

  return res.status(401).json({ error: 'Mot de passe incorrect' });
});

// ── Login avec code d'accès unique ──────────────────────
router.post('/code', (req, res) => {
  const { code } = req.body;
  const ip = req.headers['x-real-ip'] || req.ip;
  const db = getDB();

  if (!code) {
    return res.status(400).json({ error: 'Code d\'accès requis' });
  }

  const accessCode = db.prepare(`
    SELECT * FROM access_codes WHERE code = ? AND is_active = 1
  `).get(code);

  if (!accessCode) {
    db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
      .run(ip, 'code', code.substring(0, 20), 0);
    return res.status(401).json({ error: 'Code d\'accès invalide ou désactivé' });
  }

  // Vérifier expiration
  if (accessCode.expires_at && new Date(accessCode.expires_at) < new Date()) {
    db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
      .run(ip, 'code', accessCode.label, 0);
    return res.status(401).json({ error: 'Code d\'accès expiré' });
  }

  // Mettre à jour l'utilisation
  db.prepare(`
    UPDATE access_codes SET last_used_at = CURRENT_TIMESTAMP, use_count = use_count + 1 WHERE id = ?
  `).run(accessCode.id);

  db.prepare('INSERT INTO auth_logs (ip, method, identifier, success) VALUES (?, ?, ?, ?)')
    .run(ip, 'code', accessCode.label, 1);

  const token = generateToken({
    role: 'recruiter',
    label: accessCode.label,
    company: accessCode.company,
    codeId: accessCode.id
  });

  return res.json({
    token,
    role: 'recruiter',
    label: accessCode.label,
    company: accessCode.company
  });
});

// ── Vérifier la validité d'un token ─────────────────────
router.get('/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ valid: false });
  }

  try {
    const jwt = require('jsonwebtoken');
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'change_me_in_production_1234');
    return res.json({ valid: true, user: decoded });
  } catch {
    return res.status(401).json({ valid: false });
  }
});

module.exports = router;
