const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { initDB } = require('./db/init');

const app = express();
const PORT = 3001;

// ── Initialiser la base de données ──────────────────────
initDB();

// ── Middlewares ──────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());

// ── Routes ──────────────────────────────────────────────
app.use('/api/auth', require('./routes/auth'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/tracking', require('./routes/tracking'));
app.use('/api/contact', require('./routes/contact'));

// ── Health Check ────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── Démarrage ───────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 Portfolio API démarrée sur le port ${PORT}`);
  console.log(`📊 Dashboard admin: authentifiez-vous avec le mot de passe admin`);
  console.log(`🔐 Mot de passe recruteur: ${process.env.RECRUITER_PASSWORD || 'recruteur2025'}\n`);
});
