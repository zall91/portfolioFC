const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = path.join(__dirname, '..', 'data', 'portfolio.db');

let db;

function initDB() {
  const fs = require('fs');
  const dataDir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // ── Tables ────────────────────────────────────────────
  db.exec(`
    -- Codes d'accès uniques par recruteur
    CREATE TABLE IF NOT EXISTS access_codes (
      id TEXT PRIMARY KEY,
      code TEXT UNIQUE NOT NULL,
      label TEXT NOT NULL,
      company TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      expires_at DATETIME,
      is_active INTEGER DEFAULT 1,
      last_used_at DATETIME,
      use_count INTEGER DEFAULT 0
    );

    -- Visiteurs trackés
    CREATE TABLE IF NOT EXISTS visitors (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      ip TEXT,
      user_agent TEXT,
      country TEXT,
      city TEXT,
      region TEXT,
      referer TEXT,
      first_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_visit DATETIME DEFAULT CURRENT_TIMESTAMP,
      total_visits INTEGER DEFAULT 1
    );

    -- Pages vues
    CREATE TABLE IF NOT EXISTS page_views (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      visitor_id TEXT NOT NULL,
      page TEXT NOT NULL,
      entered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      time_spent_seconds INTEGER DEFAULT 0,
      FOREIGN KEY (visitor_id) REFERENCES visitors(id)
    );

    -- Tentatives de connexion (sécurité)
    CREATE TABLE IF NOT EXISTS auth_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT,
      method TEXT,
      identifier TEXT,
      success INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Messages de contact
    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      subject TEXT,
      message TEXT NOT NULL,
      ip TEXT,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  console.log('[DB] Base de données initialisée avec succès');
  return db;
}

function getDB() {
  if (!db) initDB();
  return db;
}

module.exports = { initDB, getDB };
