const { getDB } = require('../db/init');
const { v4: uuidv4 } = require('uuid');

function getGeoInfo(ip) {
  try {
    const geoip = require('geoip-lite');
    // Nettoyer l'IP (enlever ::ffff: pour IPv4-mapped IPv6)
    const cleanIP = ip.replace(/^::ffff:/, '');
    const geo = geoip.lookup(cleanIP);
    if (geo) {
      return { country: geo.country, city: geo.city, region: geo.region };
    }
  } catch (e) { /* ignore */ }
  return { country: null, city: null, region: null };
}

function trackVisitor(req, res, next) {
  // Ne pas tracker les routes API internes / health
  if (req.path.startsWith('/api/admin') || req.path === '/api/health') {
    return next();
  }

  try {
    const db = getDB();
    const ip = req.headers['x-real-ip'] || req.headers['x-forwarded-for']?.split(',')[0] || req.ip;
    const userAgent = req.headers['user-agent'] || 'unknown';
    const referer = req.headers['referer'] || null;
    const geo = getGeoInfo(ip);

    // Identifier le visiteur par IP + user-agent
    const sessionKey = `${ip}_${userAgent}`.substring(0, 200);
    
    let visitor = db.prepare('SELECT * FROM visitors WHERE session_id = ?').get(sessionKey);
    
    if (!visitor) {
      const id = uuidv4();
      db.prepare(`
        INSERT INTO visitors (id, session_id, ip, user_agent, country, city, region, referer)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, sessionKey, ip, userAgent, geo.country, geo.city, geo.region, referer);
      visitor = { id };
    } else {
      db.prepare(`
        UPDATE visitors SET last_visit = CURRENT_TIMESTAMP, total_visits = total_visits + 1
        WHERE id = ?
      `).run(visitor.id);
    }

    // Tracker la page vue
    if (req.body && req.body.page) {
      db.prepare(`
        INSERT INTO page_views (visitor_id, page) VALUES (?, ?)
      `).run(visitor.id, req.body.page);
    }

    req.visitorId = visitor.id;
  } catch (err) {
    console.error('[Tracker] Erreur:', err.message);
  }

  next();
}

module.exports = { trackVisitor };
