# Portfolio François — Édition Warmth

Portfolio professionnel pour candidature en alternance (Licence Pro ASUR).
Direction artistique éditoriale, palette terracotta + rose blush.

## Esthétique

**Parti-pris** : "Editorial Warmth" — un portfolio tech qui refuse les codes
attendus du secteur cybersécurité (bleu nuit + néon cyan). Inspiration
magazines de design (Apartamento, Cereal) appliquée au monde des serveurs.

- **Palette light** : cream `#F5EFE6` + espresso `#2B1810` + terracotta `#B5654A` + rose blush `#E8B4B8`
- **Palette dark** : cocoa `#1A0F0A` + cream `#F5EFE6` + terracotta réchauffée `#C97B6E` + rose poudré `#D4A5A5`
- **Typographies** : Fraunces (display serif) + Inter Tight (corps) + JetBrains Mono (mono)
- **Mode par défaut** : light, avec respect automatique de `prefers-color-scheme`. Toggle visible dans la sidebar.
- **Détails signatures** : soulignement manuscrit rose sous les mots-clés, ping trace au survol des projets, numérotation éditoriale `/01 /02 /03`.

## Déploiement

```bash
cd /home/tux/portfolio
cp .env.example .env
nano .env
docker compose up -d --build
```

Ou via Dockhand : crée une stack avec le contenu du `docker-compose.yml`.

## Personnalisation

Édite `frontend/src/config.js` puis :
```bash
docker compose up -d --build frontend
```

## Authentification

- Mot de passe admin (`ADMIN_PASSWORD`) → accès au Dashboard
- Mot de passe recruteur partagé (`RECRUITER_PASSWORD`) → accès aux projets
- Codes uniques par recruteur, créés depuis le Dashboard

## Stack

React + Vite + Express + SQLite + JWT + geoip-lite + Nginx + Docker.
